from Animal import Animal

class Fish(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, bernapas, habitat):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.bernapas = bernapas
        self.habitat = habitat

    def info_fish(self):
        super().info_animal()
        print("Bernapas menggunakan\t: ", self.bernapas, "\nHabitat\t\t\t: ", self.habitat)
fish = Fish ("Hiu", "Daging", "Laut", "Melahirkan", "Insang", "Air Asin")
print('## info bird ##')
fish.info_fish()
