from Animal import Animal

class Snake(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, berbisa, pola_kulit ):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.berbisa = berbisa
        self.pola_kulit = pola_kulit

    def info_snake(self):
        super().info_animal()
        print("berbisa\t\t\t: ", self.berbisa, "\nPolaKulit\t\t: ", self.pola_kulit)
snake = Snake("Cobra", "Tikus", "Hutan", "Menghasilkan telur", "Berbisa", "Bergaris-garis")
print('## info Snake ##')
snake.info_snake()
