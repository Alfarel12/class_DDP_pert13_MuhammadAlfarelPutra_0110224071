from Animal import Animal

class Bird(Animal):
    #konstruktor properti
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna, paruh):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.warna = warna
        self.paruh = paruh

    #method info
    def info_bird(self):
        super().info_animal()
        print("warna\t\t\t: ", self.warna, "\nJenis paruh\t\t:", self.paruh)
bird = Bird("Elang", "Daging", "Ditebing", "Menghasilkan telur", "Coklat", "Bengkok dan Lancip")
print('## info bird ##')
bird.info_bird()